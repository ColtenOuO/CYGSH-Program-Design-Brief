可以自動批改答案的程式

使用方式：

Step 1 : 請先將學生的答案依照 student_answer_data.xlsx 檔案的格式填入

Step 2 : 填入完畢之後，請直接全選所有資料 ( CTRL + A ) 接著複製 ( CTRL + C )

Step 3 : 接著請開啟 student_answer_pasted.txt 將剛剛複製的資料貼上 ( CTRL + V )

Step 4 : 接著請將答案依照 Test_Answer.xlsx 檔案的格式填入

Step 5 : 填入完畢之後，請直接全選所有資料 ( CTRL + A ) 接著複製 ( CTRL + C )

Step 6 : 接著請開啟 test_answer_pasted.txt 將剛剛複製的資料貼上 ( CTRL + V )

Step 7 : 開啟 main.exe 並照著黑窗的提示輸入

Step 8 : 開啟 student_score_copy.txt 後，請直接全選所有資料 ( CTRL + A ) 接著複製 ( CTRL + C )

Step 9 : 開啟 student_score.xlxs 將剛剛複製的資料貼上 ( CTRL + V )